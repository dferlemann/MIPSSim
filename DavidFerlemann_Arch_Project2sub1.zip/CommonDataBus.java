
// need to work on it after fixing project 1, otherwise don't see the point.

public class CommonDataBus {
	
	
	private boolean CDB1_Status = false;
	private boolean CDB2_Status = false;
	
	public CommonDataBus()
	{
		
	}
	
	public void CDB1()
	{
		
	}
	
	public void CDB2()
	{
		
	}
}
