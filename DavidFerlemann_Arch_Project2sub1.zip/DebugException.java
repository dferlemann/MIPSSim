

public class DebugException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DebugException (String message)
	{
		super(message);

	}
}
