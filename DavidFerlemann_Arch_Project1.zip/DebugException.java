
public class DebugException extends Exception {
	
	public DebugException (String message)
	{
		super(message);
	}
}
