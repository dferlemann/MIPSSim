import java.util.HashMap;


public interface InstructionFormat 
{
	HashMap<String, String> format(String parts);
}
