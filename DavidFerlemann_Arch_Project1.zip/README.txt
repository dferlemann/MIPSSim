
MIPS Simulator
--------------------------
Computer Architecture Project 1
By: David Ferlemann

Description:
--------------------------
This program currently only targeting to satisfy course project 1 requirements - a unpipelined MIPS simulation that takes in a file containing machine code for a program. 

Things not working yet (Future improvements):
- It doesn't support pipelined operations


Compile:
--------------------------
javac *.java


Run:
--------------------------
java RunMipsSimulator <input file>